
import React from 'react';
import type { SignatureData } from '../types';
import { BUSINESS_ENTITIES } from '../constants';

interface SignatureFormProps {
  signatureData: SignatureData;
  setSignatureData: React.Dispatch<React.SetStateAction<SignatureData>>;
  setIsEmailManuallyEdited: React.Dispatch<React.SetStateAction<boolean>>;
}

const InputField: React.FC<{ label: string; id: string; value: string; onChange: (e: React.ChangeEvent<HTMLInputElement>) => void; placeholder: string; type?: string }> = ({ label, id, value, onChange, placeholder, type = 'text' }) => (
    <div>
        <label htmlFor={id} className="block text-sm font-medium text-slate-700 mb-1">
            {label}
        </label>
        <input
            type={type}
            id={id}
            name={id}
            value={value}
            onChange={onChange}
            placeholder={placeholder}
            className="block w-full rounded-md border-slate-300 bg-white shadow-sm focus:border-green-500 focus:ring-green-500 sm:text-sm"
        />
    </div>
);

const SignatureForm: React.FC<SignatureFormProps> = ({ signatureData, setSignatureData, setIsEmailManuallyEdited }) => {

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    
    if (name === 'name') {
      setIsEmailManuallyEdited(false);
    }
    if (name === 'email') {
      setIsEmailManuallyEdited(true);
    }
    
    setSignatureData(prevData => ({ ...prevData, [name]: value }));
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold text-slate-900">Ihre Daten</h2>
        <p className="mt-1 text-sm text-slate-600">
          Füllen Sie die Felder aus, um Ihre persönliche E-Mail-Signatur zu erstellen.
        </p>
      </div>

      <InputField
        label="Vor- & Nachname"
        id="name"
        value={signatureData.name}
        onChange={handleInputChange}
        placeholder="z.B. Max Mustermann"
      />
      
      <InputField
        label="Position / Titel"
        id="title"
        value={signatureData.title}
        onChange={handleInputChange}
        placeholder="z.B. Projektmanager"
      />

      <InputField
        label="Telefon (Mobil)"
        id="phone"
        type="tel"
        value={signatureData.phone}
        onChange={handleInputChange}
        placeholder="z.B. 0170 1234567"
      />

      <div>
        <label htmlFor="email" className="block text-sm font-medium text-slate-700 mb-1">
          E-Mail Adresse
        </label>
        <input
            type="email"
            id="email"
            name="email"
            value={signatureData.email}
            onChange={handleInputChange}
            placeholder="wird automatisch generiert"
            className="block w-full rounded-md border-slate-300 bg-white shadow-sm focus:border-green-500 focus:ring-green-500 sm:text-sm"
        />
        <p className="mt-1 text-xs text-slate-500">Bitte die automatisch generierte E-Mail-Adresse überprüfen.</p>
      </div>

      <div>
        <fieldset>
          <legend className="block text-sm font-medium text-slate-700 mb-2">
            Wo bist du angestellt?
          </legend>
          <div className="space-y-2">
            {Object.entries(BUSINESS_ENTITIES).map(([key, entity]) => (
              <div key={key} className="flex items-center">
                <input
                  id={key}
                  name="entityKey"
                  type="radio"
                  value={key}
                  checked={signatureData.entityKey === key}
                  onChange={handleInputChange}
                  className="h-4 w-4 border-slate-300 text-green-600 focus:ring-green-500"
                />
                <label htmlFor={key} className="ml-3 block text-sm text-slate-800">
                  {entity.name}
                </label>
              </div>
            ))}
          </div>
        </fieldset>
      </div>
    </div>
  );
};

export default SignatureForm;