
import React, { useState, useCallback } from 'react';
import type { SignatureData } from '../types';
import { 
  BUSINESS_ENTITIES, 
  LOGO_URL, 
  LINKEDIN_URL, 
  WEBSITE_URL, 
  COMPANY_LANDLINE,
  CALENDLY_URL,
  BANNER_URL
} from '../constants';
import { ClipboardIcon } from './icons/ClipboardIcon';

interface SignaturePreviewProps {
  signatureData: SignatureData;
}

const SignaturePreview: React.FC<SignaturePreviewProps> = ({ signatureData }) => {
  const [copyButtonText, setCopyButtonText] = useState('Signatur kopieren');
  const { name, title, phone, email, entityKey } = signatureData;
  const selectedEntity = BUSINESS_ENTITIES[entityKey] || BUSINESS_ENTITIES['business_solutions'];

  const processPhoneNumber = useCallback((phoneNumber: string): { display: string; link: string } => {
    if (!phoneNumber) {
      return { display: '[Deine Mobilnummer]', link: '' };
    }
  
    // 1. Clean the number to get digits only.
    const digitsOnly = phoneNumber.replace(/\D/g, '');
    
    // 2. Normalize to the German number part (without leading 0 or country code 49)
    let numberPart = digitsOnly;
    if (digitsOnly.startsWith('0049')) {
      numberPart = digitsOnly.substring(4);
    } else if (digitsOnly.startsWith('49')) {
      numberPart = digitsOnly.substring(2);
    } else if (digitsOnly.startsWith('0')) {
      numberPart = digitsOnly.substring(1);
    }
  
    if (!numberPart) {
       return { display: '[Deine Mobilnummer]', link: '' };
    }

    // 3. Create the link version (e.g., +491721234567)
    const link = `+49${numberPart}`;
    
    // 4. Create the display version with proper spacing based on length
    let formattedNumberPart = '';
    
    // Common German mobile numbers have 10 or 11 digits after the leading 0.
    if (numberPart.length === 10) { // e.g. 172 1234567 -> 172 123 45 67
        formattedNumberPart = `${numberPart.substring(0, 3)} ${numberPart.substring(3, 6)} ${numberPart.substring(6, 8)} ${numberPart.substring(8, 10)}`;
    } else if (numberPart.length === 11) { // e.g. 1511 1234567 -> 1511 123 45 67
        formattedNumberPart = `${numberPart.substring(0, 4)} ${numberPart.substring(4, 7)} ${numberPart.substring(7, 9)} ${numberPart.substring(9, 11)}`;
    } else if (numberPart.length === 9) { // Older format
        formattedNumberPart = `${numberPart.substring(0, 3)} ${numberPart.substring(3, 6)} ${numberPart.substring(6, 9)}`;
    } else {
        // A generic fallback for any other length.
        const prefix = numberPart.substring(0, 3);
        const rest = numberPart.substring(3);
        formattedNumberPart = `${prefix} ${rest}`;
    }

    const display = `+49 ${formattedNumberPart}`;
  
    return { display, link };
  }, []);

  const generateSignatureHtml = useCallback(() => {
    if (!selectedEntity) {
      return '<div>Bitte wählen Sie eine gültige Einheit aus.</div>';
    }

    const displayName = name || '[Dein Name]';
    
    const titleHtml = title ? `<p style="margin: 2px 0 0 0; color: #333333;">${title}</p>` : '';
    
    const { display: displayPhone, link: linkPhone } = processPhoneNumber(phone);
    const phoneHtml = phone ? `<tr><td style="font-weight: bold; padding-right: 8px;">M</td><td><a href="tel:${linkPhone}" style="color: #000001; text-decoration: none;">${displayPhone}</a></td></tr>` : '';
    
    const displayEmail = email || '[deine.email@enviria.energy]';
    const emailHtml = email ? `<tr><td style="font-weight: bold; padding-right: 8px;">E</td><td><a href="mailto:${displayEmail}" style="color: #000001; text-decoration: none;">${displayEmail}</a></td></tr>` : '';

    const addressHtml = `${selectedEntity.addressLine1}<br>${selectedEntity.addressLine2} | Germany`;

    return `
      <table role="presentation" cellspacing="0" cellpadding="0" border="0" style="font-family: Arial, sans-serif; font-size: 11pt; color: #000001; width: 100%; max-width: 600px;">
        <tbody>
          <!-- Name and Title -->
          <tr>
            <td colspan="2" style="padding-bottom: 16px;">
              <p style="margin: 0; font-size: 14pt; font-weight: bold; color: #008d97;">${displayName}</p>
              ${titleHtml}
            </td>
          </tr>
          <!-- Logo and Contact Details -->
          <tr>
            <td valign="top" style="width: 150px; padding-top: 12px; padding-right: 20px;">
              <a href="${WEBSITE_URL}" target="_blank" style="text-decoration: none;">
                <img src="${LOGO_URL}" width="140" alt="Enviria Logo" style="width: 140px; border: 0; display: block;">
              </a>
            </td>
            <td valign="top" style="padding-top: 12px; line-height: 1.5;">
              <table role="presentation" cellspacing="0" cellpadding="0" border="0" style="font-size: 11pt; color: #000001;">
                <tbody>
                  ${phoneHtml}
                  <tr><td style="font-weight: bold; padding-right: 8px;">T</td><td><a href="tel:${COMPANY_LANDLINE.replace(/\s/g, '')}" style="color: #000001; text-decoration: none;">${COMPANY_LANDLINE}</a></td></tr>
                  ${emailHtml}
                </tbody>
              </table>
              <p style="margin: 12px 0 0 0; line-height: 1.4;">
                <span style="color: #000001;">${selectedEntity.name}</span><br>
                <span style="color: #333333;">${addressHtml}</span>
              </p>
            </td>
          </tr>
          <!-- Social/Web Links -->
          <tr>
            <td colspan="2" style="padding-top: 16px; font-size: 10pt; color: #d8601e;">
              <a href="${LINKEDIN_URL}" style="color: #d8601e; text-decoration: none; font-weight: bold;">LinkedIn</a>
              <span style="color: #AAAAAA;">&nbsp;|&nbsp;</span>
              <a href="${WEBSITE_URL}" style="color: #d8601e; text-decoration: none; font-weight: bold;">www.enviria.energy</a>
              <span style="color: #AAAAAA;">&nbsp;|&nbsp;</span>
              <a href="${CALENDLY_URL}" style="color: #d8601e; text-decoration: none; font-weight: bold;">Buchen Sie einen Termin</a>
            </td>
          </tr>
          <!-- Banner -->
          <tr>
            <td colspan="2" style="padding-top: 16px;">
              <a href="${WEBSITE_URL}" target="_blank">
                <img src="${BANNER_URL}" alt="Enviria Banner" style="display: block; border: 0; width: 100%; max-width: 600px;">
              </a>
            </td>
          </tr>
          <!-- Footer -->
          <tr>
            <td colspan="2" style="padding-top: 15px;">
              <div style="font-size: 8pt; font-family: Arial; color: #555555; line-height: 1.3;">
                <p style="margin: 0;">CEO / Geschäftsführer: ${selectedEntity.ceo}</p>
                <p style="margin: 0;">Sitz der Gesellschaft: ${selectedEntity.registeredOffice}</p>
                <p style="margin: 0;">${selectedEntity.registration}</p>
                <p style="margin: 10px 0; color: #008D97;">Save a tree. Don’t print this e-mail.</p>
                <p style="margin: 0; font-size: 7.5pt">This e-mail message and any attachments are being sent by ENVIRIA Energy Holding GmbH and its subsidiaries, are confidential, and may be proprietary or privileged. If you are not the named or intended addressee, please notify us immediately either by replying to this message or by sending an e-mail to&nbsp;<a href="mailto:info@enviria.energy" style="color: #d8601e; text-decoration: none;">info@enviria.energy</a>&nbsp;and delete all copies of this message and any attachments. Moreover, you should not disseminate, distribute or copy this e-mail.</p>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    `;
  }, [name, title, phone, email, selectedEntity, processPhoneNumber]);

  const handleCopyToClipboard = () => {
    const htmlString = generateSignatureHtml();
    
    const listener = (e: ClipboardEvent) => {
        if (!e.clipboardData) return;
        e.clipboardData.setData('text/html', htmlString);
        e.clipboardData.setData('text/plain', name || 'Enviria Signature'); // Fallback
        e.preventDefault();
    };

    document.addEventListener('copy', listener);
    document.execCommand('copy');
    document.removeEventListener('copy', listener);
    
    setCopyButtonText('Kopiert!');
    setTimeout(() => setCopyButtonText('Signatur kopieren'), 2000);
  };

  return (
    <div className="flex flex-col h-full">
      <div>
        <h2 className="text-xl font-semibold text-slate-900">Vorschau</h2>
        <p className="mt-1 text-sm text-slate-600">
          So wird Ihre Signatur in E-Mails aussehen.
        </p>
      </div>
      
      <div className="mt-6 flex-grow p-6 border border-slate-200 rounded-lg bg-white min-h-[350px] overflow-auto">
        <div dangerouslySetInnerHTML={{ __html: generateSignatureHtml() }} />
      </div>

      <div className="mt-6">
        <button
          onClick={handleCopyToClipboard}
          className="w-full flex items-center justify-center px-4 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-[#008d97] hover:bg-[#007a83] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#008d97] transition-all duration-150"
        >
          <ClipboardIcon className="w-5 h-5 mr-2" />
          {copyButtonText}
        </button>
        <p className="text-xs text-slate-500 mt-3 text-center">
            Kopieren Sie die Signatur und fügen Sie sie in den Signatur-Einstellungen Ihres E-Mail-Programms (z.B. Outlook) ein.
        </p>
      </div>
    </div>
  );
};

export default SignaturePreview;
